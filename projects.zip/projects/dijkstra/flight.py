from airport import Airport
from haversine import haversine, Unit

class Flight():
    def __init__(self, origin: Airport, destination: Airport) -> None:
        self._origin: Airport = origin
        self._destination: Airport = destination

    @property
    def weight(self) -> float:
        origin = (self._origin.latitude, self._origin.longitude)
        destination = (self._destination.latitude, self._destination.longitude)
        return haversine(origin, destination, Unit.MILES)
    
    def __lt__(self, object: any) -> bool:
        if not isinstance(object, Flight):
            return False
        
        return self.weight < object.weight
    
    @property
    def destination(self) -> Airport:
        return self._destination
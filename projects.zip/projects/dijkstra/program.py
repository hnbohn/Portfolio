import csv
from graph import Graph
from airport import Airport
from flight import Flight
import numpy

def read_csv(filename: str) -> Graph:
    # reads csv file in, creates graph object
    graph = Graph()

    csv_reader = csv.DictReader(open(filename, newline="\n", encoding="utf-8-sig"))

    for row in csv_reader:
        origin = Airport(
            int(row['origin_airport_id']), 
            row['origin_airport'], 
            row['origin_airport_code'], 
            row['origin_city'], 
            row['origin_country'], 
            float(row['origin_airport_latitude']), 
            float(row['origin_airport_longitude']))
        
        destination = Airport(
            int(row['destination_airport_id']), 
            row['destination_airport'], 
            row['destination_airport_code'], 
            row['destination_city'], 
            row['destination_country'], 
            float(row['destination_airport_latitude']), 
            float(row['destination_airport_longitude']))

        flight = Flight(origin, destination)
        weight = flight.weight
        graph.add_edge(origin, destination, flight, weight)

    return graph



def main():
    # user input determines origin airport location and final airport destination, calculates shortest path
    origin_input = input("Enter origin airport code or Q to quit: ").upper()
    graph: Graph = read_csv("./projects/dijkstra/routes.csv")

    while origin_input.upper() != "Q":
        origin_null = None
        destination_null = None
        destination_input = input("Enter destination airport code: ").upper()
        local = []

        for airport in graph.vertices:
            if airport.code == origin_input:
                origin_null = airport
            if airport.code == destination_input:
                destination_null = airport
            
        if origin_null == None or destination_null == None:
            print("Invalid airport code.")
            return
        
        origin_airport = origin_null
        destination_airport = destination_null

        distances = {}
        for airport in graph.vertices:
            distances[airport] = [numpy.inf, False, None]
        distances[origin_airport] = [0, False, None]
        current = origin_airport

        while destination_airport != current:
            short_distance = numpy.inf

            for distance in distances:
                if distances[distance][1] == True:
                    continue
                if distances[distance][0] < short_distance:
                    short_distance = distances[distance][0]
                    current = distance

            for edge in graph.edges_from(current):
                if distances[edge.destination_airport][0] > distances[current][0] + edge.weight:
                    distances[edge.destination_airport][0] = distances[current][0] + edge.weight
                    distances[edge.destination_airport][2] = current
            distances[current][1] = True

        while current != origin_airport:
            local.append(current)
            current = distances[current][2]
        print(f"Starting airport: {origin_airport.name} ({origin_airport.code})")

        for i in range(len(local) - 1, 0, -1):
            print(f"{len(local) - i}: {local[i].name} ({destination_airport.code})")
        
        print(f"Destination airport: {destination_airport.name} ({destination_airport.code})")
        print(f"Total distance: {distances[destination_airport][0]}")
        
        origin_airport = input("Enter the origin airport code or type Q to quit: ")

    print("Safe travels!")
            





if __name__ == "__main__":
    main()
from typing import NamedTuple

class Airport(NamedTuple):
    id: int
    name: str
    code: str
    city: str
    country: str
    latitude: float
    longitude: float
# Evolution of Dance

This is my complete evolution of dance game.

# Instructions

1. Type 0 to quit

# Example Run

How many rounds?25
Initial list of dancers: [❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ].
💚  Green initiates Footloose: [❤️ ,🧡 ,💛 ,💚 ,💚 ,💙 ,💜 ,🩷 ]
❤️  Red initiates TheTwist: [❤️ ,🧡 ,💛 ,💚 ,💚 ,💙 ,💜 ,🩷 ,❤️ ]
❤️  Red initiates TheTwist: [❤️ ,🧡 ,💛 ,💚 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,❤️ ]
🩷  Pink initiates RunningMan: [🩷 ,❤️ ,🧡 ,💛 ,💚 ,🩷 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,❤️ ,🩷 ]
💜  Purple initiates Footloose: [🩷 ,❤️ ,🧡 ,💛 ,💜 ,💚 ,🩷 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,❤️ ,🩷 ]
💚  Green initiates TheTwist: [🩷 ,❤️ ,🧡 ,💛 ,💜 ,💚 ,🩷 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,❤️ ,🩷 ,💚 ]
🩷  Pink initiates DiscoDancing: [❤️ ,🩷 ,❤️ ,🧡 ,💛 ,💜 ,💚 ,🩷 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ,💛 ,💚 ,💙 
,💜 ,🩷 ]
🩷  Pink initiates DiscoDancing: [🩷 ,❤️ ,🩷 ,❤️ ,🧡 ,💛 ,💜 ,💚 ,🩷 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ,💛 ,💚 
,💙 ,💜 ,🩷 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ]
PS C:\Users\haley\GitHub\cs152-assignments-repo-hnbohn>  c:; cd 'c:\Users\haley\GitHub\cs152-assignments-repo-hnbohn'; & 'c:\Users\haley\AppData\Local\Programs\Python\Python311\python.exe' 'c:\Users\haley\.vscode\extensions\ms-python.debugpy-2024.2.0-win32-x64\bundled\libs\debugpy\adapter/../..\debugpy\launcher' '52331' '--' '-m' 'projects.evolutionofdance.program' 
How many rounds?25
Initial list of dancers: [❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ].
❤️  Red initiates TheTwist: [❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,❤️ ]
🩷  Pink initiates TheTwist: [❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ]
💚  Green initiates TheTwist: [❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ]
❤️  Red initiates TheTwist: [❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ]
❤️  Red initiates MoonWalk: [❤️ ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ]
🧡  Orange initiates RunningMan: [🧡 ,❤️ ,❤️ ,🧡 ,💛 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ]
💙  Blue initiates MoonWalk: [💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ]
💜  Purple initiates CupidShuffle: [💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ]
💙  Blue initiates CupidShuffle: [💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ]
🧡  Orange initiates MoonWalk: [🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ]
🧡  Orange initiates MoonWalk: [🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ]
🩷  Pink initiates CupidShuffle: [🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ]
💛  Yellow initiates CupidShuffle: [🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ]
🧡  Orange initiates RunningMan: [🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ,🧡 
]
🧡  Orange initiates RunningMan: [🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ 
,🧡 ,🧡 ,🧡 ]
🩷  Pink initiates DiscoDancing: [💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 
,❤️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ]
🧡  Orange initiates TheTwist: [💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤
️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,🧡 ]
🩷  Pink initiates DiscoDancing: [🧡 ,💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 
,💚 ,❤️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ]
💙  Blue initiates TheTwist: [🧡 ,💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,🩷 ,💚 
,❤️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,💙 ]
💛  Yellow initiates MoonWalk: [💛 ,🧡 ,💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,🩷 ,❤️ ,�
  ,💚 ,❤️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,💙 ]
🩷  Pink initiates DiscoDancing: [💙 ,💛 ,🧡 ,💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,🩷 
,❤️ ,🩷 ,💚 ,❤️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,💙 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,   
🩷 ]
💛  Yellow initiates MoonWalk: [💛 ,💙 ,💛 ,🧡 ,💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,� �  ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,💙 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜   
 ,🩷 ]
💙  Blue initiates TheTwist: [💛 ,💙 ,💛 ,🧡 ,💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,💚 ,🧡 ,💙 ,💜 ,🩷 
,❤️ ,🩷 ,💚 ,❤️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,💙 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,   
🩷 ,💙 ]
🩷  Pink initiates Footloose: [💛 ,💙 ,💛 ,🧡 ,💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,🩷 ,💚 ,🧡 ,💙 ,💜
 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,💙 ,❤️ ,🧡 ,💛 ,💚 ,💙     
,💜 ,🩷 ,💙 ]
💜  Purple initiates CupidShuffle: [💛 ,💙 ,💛 ,🧡 ,💜 ,🧡 ,🧡 ,🧡 ,🧡 ,💙 ,🧡 ,❤️ ,❤️ ,🧡 ,💛 ,🧡 ,🧡 ,🩷 ,💚 ,🧡 ,�
  ,💜 ,🩷 ,❤️ ,🩷 ,💚 ,❤️ ,🧡 ,🧡 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,🧡 ,❤️ ,🧡 ,💛 ,💚 ,💙 ,💜 ,🩷 ,💙 ,❤️ ,🧡 ,💛 ,💚    
 ,💙 ,💜 ,🩷 ,💙 ]

# Limitations

None nodes added to the linked list, instead of new dancers.



import random
import time
from datastructures.linked_list import LinkedList
from projects.evolutionofdance.Dancer import Dancer

# emoji = windowkey + period
dancers = [
    Dancer('Red', '❤️ '), 
    Dancer('Orange', '🧡 '),             
    Dancer('Yellow', '💛 '),
    Dancer('Green', '💚 '),
    Dancer('Blue', '💙 '),
    Dancer('Purple', '💜 '),
    Dancer('Pink', '🩷 ')
]


dance_styles =  [
    'MoonWalk',
    'TheTwist',
    'Footloose',
    'CupidShuffle',
    'RunningMan',
    'DiscoDancing'
]


def main():
    dancers_list = LinkedList()
    rounds = int(input('How many rounds?'))
    if rounds == 0:
        return print ('Game over.')

    passed_rounds = 0
    
    for dancer in dancers:
        dancers_list.append(dancer)
    print(f'Initial list of dancers: {dancers_list}.')

    play_again = True

    while passed_rounds < rounds or play_again:         
        dancer = random.choice(dancers)
        dance_style = random.choice(dance_styles)
        
        if dance_style == 'MoonWalk':
            dancers_list.prepend(dancer)

        elif dance_style == 'TheTwist':
            dancers_list.append(dancer)

        elif dance_style == 'Footloose':
            # the new dancer joins the line at a random position X, where X <= length of the line
            dancers_list.insert(dancer, random.randint(0, len(dancers_list)))

        elif dance_style == 'CupidShuffle':
            # remove the first matching dancer from the line and then add the new dancer to the end of the line.          
            current = dancers_list.head
            while current is not None and current != dancer:
                current = current.next

            if current is not None:
                dancers_list.remove(current)
                dancers_list.append(dancer)

        elif dance_style == 'RunningMan':
            # take the new dancer and generate two more matching dancers. 
            # Place one dancer at the front of the line, one dancer in the middle of the line, 
            # and the other dancer at the end of the line.
            new_dancer1 = Dancer(dancer._name, dancer._icon)
            new_dancer2 = Dancer(dancer._name, dancer._icon)
            dancers_list.prepend(new_dancer1) 
            dancers_list.insert(new_dancer2, len(dancers_list) // 2)
            dancers_list.append(new_dancer1)
            
        elif dance_style == 'DiscoDancing':
            # Add the dancer to the front of the line, then add one of each dancer type to the end of the line.
            dancers_list.prepend(dancer)
            for dancer in dancers:
                dancers_list.append(dancer)
            

        time.sleep(1)

        print(f'{dancer._icon} {dancer._name} initiates {dance_style}: {dancers_list}')

        passed_rounds += 1

        if passed_rounds >= rounds:
            play_again = input('Do you want to play again?') == 'Yes'
            if play_again == True:
                dancers_list.clear()
                main()
            else:
                return

    

    

if __name__ == '__main__':
    main()
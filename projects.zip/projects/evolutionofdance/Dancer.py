

class Dancer:

    def __init__(self, name, icon) -> None:
        self._name = name
        self._icon = icon

    def __str__(self):
        return self._icon
    
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Dancer):
            return False
        
        return other._name == self._name and other._icon == self._icon
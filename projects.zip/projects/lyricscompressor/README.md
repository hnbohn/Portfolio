
# Lyrics Compressor

This is my completed lyrics compressor.

## Instructions on how to run

1. When prompted input filename

2. To compress lyrics file, press 1

3. To debug hashmap, press 2

4. To decompress lyrics file, press 3

5. Exit, press 4



# Limitations

Reconstruction of file using decompress does not properly reincoorporate line breaks.
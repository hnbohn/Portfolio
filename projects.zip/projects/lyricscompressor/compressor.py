from datastructures.hash_map import HashMap
from fileutils import FileUtils

class Compressor:
    def __init__(self, file_utils: FileUtils):
        self._file_utils = file_utils

    def compress_lyrics(self, lyrics: list[str]) -> HashMap:
        word_map = HashMap()
        position = 0

        for _, line in enumerate(lyrics):
            words = line.split(" ")

            for _, word in enumerate(words):
                factor = -1 if "\n" in word else 1
                if word not in word_map:
                    word_map[word.strip()] = [position*factor]
                else:
                    word_map[word.strip()].append(position*factor)

                position += 1

        return word_map

    def decompress_lyrics(self, compressed_map: HashMap) -> str:
        size = 1000

        decompressed_lines = ['']*size

        for key, value in compressed_map.items():
            for pos in value:
                word = key if pos >= 0 else key + "\n"
                decompressed_lines[abs(pos)] = word

        return " " .join(decompressed_lines)
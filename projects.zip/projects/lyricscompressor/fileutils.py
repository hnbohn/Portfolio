
class FileUtils:
    @staticmethod
    def read(filename: str) -> list[str]:
        with open(filename, 'r') as file:
            return file.readlines()

    @staticmethod
    def write(filename: str, text: str) -> None:
        with open(filename, 'w') as file:
            file.write(text)
from datastructures.hash_map import HashMap
from fileutils import FileUtils
from compressor import Compressor

class Program:
    def __init__(self):
        self._compressor = Compressor(FileUtils())

    def run(self):
        filename = input("Enter filename: ")
        filename = f"./projects/lyricscompressor/{filename}"

        selection = input("(1) compress (2) debug map (3) decompress (4) exit: ")

        while selection != "4":
            if selection == "1":
                lyrics = FileUtils.read(filename)
                self.compressed_map = self._compressor.compress_lyrics(lyrics)

            elif selection == "2":                
                print("Debugging compressed map:")
                for key, value in self.compressed_map.items():
                    print(f"{key}: {value}")

            elif selection == "3":
                filename = input('Enter the filename.')
                decompressed_lyrics = self._compressor.decompress_lyrics(self.compressed_map)
                FileUtils.write(filename, decompressed_lyrics)
                print(f"Lyrics decompressed and saved as {filename}.")

            elif selection == "4":
                return
            
            else:
                print("Invalid input.")

            selection = input("(1) compress (2) debug map (3) decompress (4) exit: ")
            


def main():

    Program().run()

if __name__ == "__main__":
    main()

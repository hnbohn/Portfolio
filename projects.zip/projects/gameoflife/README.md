# Game of Life

This is my incompleted game of Life

## Instructions on how to run

1. Type S for step

2. Type C for continue

3. Type Q for quit

4. Press ESC to end game

5. Type 1 or 2 to increase game speed

6. Press ENTER to manually edit number of generation ###
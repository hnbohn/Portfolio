from .Lifeform import Lifeform


class Bacteria(Lifeform):
    def __init__(self, is_alive: bool) -> None:

        super().__init__(is_alive, 'X')


    def evolve(self, number_of_neighbors: int) -> None:

        if number_of_neighbors == 0 or number_of_neighbors == 1:
            self._is_alive = False

        if number_of_neighbors == 3:
            self._is_alive = True
        
        elif number_of_neighbors >= 4:
            self._is_alive = False

    def __eq__(self, other):
        if not isinstance(other, Bacteria):
            return False
        return self._is_alive == other.is_alive and self._symbol == other.symbol
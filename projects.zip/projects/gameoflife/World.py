from .Bacteria import Bacteria
import time
import copy
import random
from .kbhit import KBHit

from datastructures.array2d import Array2D


class World:
    def __init__(self, size: int = 4, filename: str = ''):
        self._grid = self._initialize_grid(size, filename)
        self._grid_history: list[Array2D] = []


    def _initialize_grid(self, size: int, filename: str) -> Array2D:        # creating Bacteria randomly

        if filename != '':
            return self._build_grid_from_file(filename)

        grid = Array2D(size, size)

        for row in range(size):
            for col in range(size):
                is_alive = random.choice([True, False])
                grid[row][col] = Bacteria(is_alive)

        return grid


    def print_current_grid(self) -> None:

        rows, cols = self._grid.dimensions

        for row in range(rows):
            for col in range(cols):
                print(self._grid[row][col], end = ' ')

            print()

        print('-----')

    def _build_grid_from_file(self, filename) -> Array2D:           
        with open(filename, 'r') as file:
            data = file.readlines()

        for string in data:
            string.rstrip()
        
        grid = Array2D(len(data), len(data))
        
        for i in range(len(data)):
            for j in range(len(data)):
                if data[i][j] == 'X':
                    grid[i][j] = Bacteria(is_alive = True)
                else:
                    grid[i][j] = Bacteria(is_alive = False)
    
        return grid


    def run(self):
        kb_hit = KBHit()

        generation = 0
        step = False
        speed = 1

        while True:
            if self._reached_stable_state():
                print(f'Reached stable or stagnant state after {generation} generations.')
                step = True
                print("Type C to start new game or ESC to end.")
                break

            generation += 1
        
            self.print_current_grid()

            next_generation = copy.deepcopy(self._grid)

            rows, cols = next_generation.dimensions

            for row in range(rows):
                for col in range(cols):
                    neighbors = self._get_neighbors(row, col)
                    next_generation[row][col].evolve(neighbors)

            self._grid_history.append(self._grid)

            self._grid = next_generation

            time.sleep(speed)

            if step or kb_hit.kbhit():
                character = kb_hit.getch()
                # Speed
                if character == '1':
                    speed = 0.75
                elif character == '2':
                    speed = 0.5

                if character == 's':                                # step
                    step = True
                    continue
                elif character == 'q':                              # quit
                    return False
                elif character == 'c':                              # continue
                    main()

                else:
                    print('Invalid input.')


    def _get_neighbors(self, row: int, col: int) -> int:
        count = 0
        rows, cols = self._grid.dimensions

        if row != 0:
            if col != 0:
                if str(self._grid[row - 1][col - 1]) == 'X':
                    count += 1
            if str(self._grid[row - 1][col]) == 'X':
                    count += 1
            if col != len(self._grid[0]) - 1:
                if str(self._grid[row - 1][col + 1]) == 'X':
                    count += 1
        if col != 0:
            if str(self._grid[row][col - 1]) == 'X':
                count += 1
            if row != len(self._grid[0]) - 1:
                if str(self._grid[row + 1][col - 1]) == 'X':
                    count += 1
        if col != len(self._grid[0]) - 1:
            if str(self._grid[row][col + 1]) == 'X':
                    count += 1
            if row != len(self._grid[0]) - 1:
                if str(self._grid[row + 1][col + 1]) == 'X':
                    count += 1
        if row != len(self._grid[0]) - 1:
            if str(self._grid[row + 1][col]) == 'X':
                    count += 1

        return count    

        # for r in range(-1, 2):
        #     for c in range(-1, 2):
        #         if row > 0 and col > 0 and row < rows - 1 and col < cols - 1:
        #             if self._grid[r + row][c + col]:
        #                 count += 1


    def _reached_stable_state(self):
        if len(self._grid_history) >= 3:
                if self._grid_history[-1] == self._grid_history[-3]:
                    return True
        elif len(self._grid_history) >= 2:
            if self._grid_history[-1] == self._grid_history[-2]:
                return True

        return False

from .World import World


def main():
 
    world = World()

    world.run()

    # filename = "projects/gameoflife/grid.txt"

if __name__ == '__main__':
    main()
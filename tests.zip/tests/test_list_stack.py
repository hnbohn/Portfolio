from datastructures.list_stack import ListStack


def test_push_add_item_to_stack():
    test_stack = ListStack()
    for i in range(10):
        test_stack.push(i)

    assert 10 == len(test_stack)

    for i in range(10):
        assert test_stack.pop() == 9 - i




        
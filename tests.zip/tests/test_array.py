# This is a file you can copy/paste to create a new test file.
# Just make sure the new name starts with test_ and ends with .py.

# import data structures like this:
# from datastructures.array import Array
import pytest 
from datastructures.array import Array

class TestArray:
    def test_set_opperator_should_raise_index_error_for_negative_value(self):
        # Arrange (set up your test data)
        test_array = Array(10)

        # Act (perform the action you want to test) & Assert (check that the test is passing)
        with pytest.raises(IndexError):
            test_array[-1]

    def test_bracket_opperator_get_and_set(self):
        # Arrange
        test_array = Array(10)

        # Act
        for i in range(10):
            test_array[i] = i

        # Assert
        for i in range(10):
            assert test_array[i] == i

    def test_create_array_from_list(self):
        # Arrange
        test_from_list = [1, 2, 3, 4, 5]
        test_array = Array(len(test_from_list))

        # Act
        for i in range(len(test_from_list)):
            test_array[i] = test_from_list[i]

        # Assert
        for i in range(len(test_from_list)):
            assert test_array[i] == test_from_list[i]

    def test_append_array(self):
        # Arrange
        test_array = Array.from_list([])

        # Act
        test_array.append(1)

        # Assert
        assert len(test_array) == 1

    def test_resize_array(self):
        # Arrange
        test_array = Array(5)

        # Act
        test_array.resize(10)

        # Assert
        assert len(test_array) == 10

    def test_eq_array(self):
        # Arrange
        test_array1 = Array.from_list([1, 2, 3, 4, 5])
        test_array2 = Array.from_list([1, 2, 3, 4, 5])

        # Act
        test_result = test_array1 == test_array2

        # Assert
        assert test_result == True

    def test_if_array(self):
        # Arrange
        test_array = Array.from_list([1, 2, 3, 4, 5])
        test_str = 'Test'

        # Act
        test_result = test_array == test_str

        # Assert
        assert test_result == False

    def test_ne_array(self):
        # Arrange
        test_array1 = Array.from_list([1, 2, 3, 4, 5])
        test_array2 = Array.from_list([6, 7, 8, 9, 10])

        # Act
        test_result = test_array1 != test_array2

        # Assert
        assert test_result == True

    def test_iter_array(self):
        #Arrange
        test_array = Array.from_list([1, 2, 3, 4, 5])
        test_expected = 1

        # Act & Assert
        for item in test_array:
            assert item == test_expected

            test_expected += 1

    def test_reversed_array(self):
        # Arrange
        test_array = Array.from_list([1, 2, 3, 4, 5])
        test_expected = 5

        # Act & Assert
        for item in reversed(test_array):
            assert item == test_expected

            test_expected -= 1

    def test_delitem_array(self):
        # Arrange
        test_array = Array.from_list([1])

        # Act
        del test_array[0]

        # Assert
        assert len(test_array) == 0

    def test_contains_array(self):
        # Arrange
        test_array = Array.from_list([1, 2, 3])
        test_expected = 3

        # Act
        result = test_expected in test_array

        # Assert
        assert result == True

    def test_does_not_contain_array(self):
        # Arrange
        test_array = Array.from_list([1, 2, 3])
        test_expected = 5

        # Act
        result = test_expected not in test_array

        # Assert
        assert result == True

    def test_clear_array(self):
        # Arrange
        test_array = Array.from_list([1, 2, 3, 4, 5])

        # Act
        test_array.clear()

        # Assert
        assert len(test_array) == 0

    def test_str(self):
        #Arrange
        test_array = Array.from_list([1, 2, 3, 4, 5])

        # Act
        test_str = str(test_array)

        # Assert
        assert test_str is not None

    def test_repr(self):
        #Arrange
        test_array = Array.from_list([1, 2, 3, 4, 5])

        # Act
        test_repr = repr(test_array)

        # Assert
        assert test_repr is not None

    # Midterm
    def test_array_to_linked_list(self):
        # Arrange
        test_array = [1, 2, 3, 4, 5]
        test_linked_list = self.to_linked_list(test_array)

        # Act
        travel = self._linked_list.head
        for item in test_array:
            test_linked_list.append(item)
            travel = travel.next

        # Assert
        assert test_linked_list == test_array

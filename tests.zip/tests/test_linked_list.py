# This is a file you can copy/paste to create a new test file.
# Just make sure the new name starts with test_ and ends with .py.

# import data structures like this:
# from datastructures.array import Array
from datastructures.linked_list import LinkedList


class TestLinkedList:
    def test_append_should_insert_5_after_4(self):
        # Arrange (set up your test data)
        linked_list = LinkedList()
        expected = 0

        for i in range(5):
            if i ==3:
                continue
            linked_list.append(i)

        # Act (perform the action you want to test)
        linked_list.insert_after(2, 3)

        # Assert (check that the test is passing)
        travel_node = linked_list.head

        while travel_node is not None:
            assert expected == travel_node.item
            expected += 1
            travel_node = travel_node.next

    def test_append_should_append_5_things(self):
        # Arrange (set up your test data)
        linked_list = LinkedList()
        expected = 0

        # Act (perform the action you want to test)
        for i in range(5):
            linked_list.append(i)

        # Assert (check that the test is passing)
        travel_node = linked_list.head

        while travel_node is not None:
            assert expected == travel_node.item
            expected += 1
            travel_node = travel_node.next

    def test_prepend_should_prepend_5_things(self):
        # Arrange (set up your test data)
        linked_list = LinkedList()
        expected = 4

        # Act (perform the action you want to test)
        for i in range(4, -1, -1):
            linked_list.prepend(i)

        # Assert (check that the test is passing)
        travel_node = linked_list.head

        while travel_node is not None:
            assert expected == travel_node.item
            expected -= 1
            travel_node = travel_node.next

    # Midterm
    def test_linked_list_to_array(self):
        # Arrange
        test_linked_list = LinkedList()
        test_linked_list.append(1)
        test_linked_list.append(2)
        test_linked_list.append(3)
        test_linked_list.append(4)
        test_linked_list.append(5)

        # Act
        test_array = self.to_array(test_linked_list)
        expected_array = [1, 2, 3, 4, 5]

        # Assert
        assert test_array == expected_array
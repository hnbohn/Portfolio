from __future__ import annotations
from typing import Any

from datastructures.list_node import ListNode
#datastructures.


class LinkedList:
    """ Class LinkedList - representing an unordered linked list
        Depends on ListNode class to store the data, previous, and next nodes.
            Stipulations:
            1. Must manage the linked list using two ListNode objects (__head and __tail)
            2. Must adhere to the docstring requirements per method, including raising
               raising appropriate exceptions where indicated.
    """

    def __init__(self) -> None:
        """ Constructor for the LinkedList constructs an empty linked list.

        Examples:
            >>> self._linked_list = LinkedList()
            >>> print(self._linked_list)
            []
        
        Returns:
            None
        
        """
        self._size = 0
        self._head = None
        self._tail = None

    @staticmethod
    def from_list(py_list: list) -> LinkedList:
        """ Create a new LinkedList from a Python list.

        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(self._linked_list)
            ['cat', 'dog', 'bird']
        
        Args:
            py_list (list): list to convert to a linked list.

        Returns:
            A new LinkedList instance.
        
        Raises:
            TypeError: if py_list is not a list.
        """
        if not isinstance(py_list, list):
            raise TypeError ('py_list is not a list.')

        new_list = LinkedList()
        for item in py_list:
            new_list.append(item)

        return new_list

    def append(self, item: Any) -> None:
        """ Append an item to the end of the list.

        Examples:
            >>> self._linked_list = LinkedList()
            >>> self._linked_list.append('cat')
            >>> self._linked_list.append('dog')
            >>> print(self._linked_list)
            ['cat', 'dog']
        
        Args:
            item: the desired data to append to the linked list.
        
        Returns:
            None
        """
        if self._head is None:
            new_node = ListNode(item)
            self._head = new_node
            self._tail = new_node

        else:
            new_node = ListNode(item)
            new_node.previous = self._tail
            self._tail.next = new_node
            self._tail = new_node

        self._size += 1
        
    def prepend(self, item: Any) -> None:
        """ Prepend an item to the beginning of the list.
        
        Examples:
            >>> self._linked_list = LinkedList()
            >>> self._linked_list.prepend('cat')
            >>> self._linked_list.prepend('dog')
            >>> print(self._linked_list)
            ['dog', 'cat']
        
        Args:
            item (Any): the desired data to prepend to the linked list.
            
        Returns:
            None
        
        """
        if self._head is None:
            new_node = ListNode(item)
            self._head = new_node
            self._tail = new_node

        else:
            new_node = ListNode(item)
            new_node.next = self._head
            self._head.previous = new_node
            self._head = new_node

        self._size += 1

    def insert_before(self, before_item: Any, new_item: Any) -> None:
        """ Insert a new item before a specified item.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> self._linked_list.insert_before('dog', 'fish')
            >>> print(self._linked_list)
            ['cat', 'fish', 'dog', 'bird']
                
        Args:
            before_item (Any): the item that the user wishes to insert before.
            new_item (Any): the desired item to insert.
        
        Returns:
            None
        
        Raises:
            KeyError: if before_item is not found.
        """
        travel = self._head

        while travel is not None and travel.item != before_item:
            travel = travel.next

        if travel is None:
            raise IndexError(f'Did not find the node with value {before_item}.')

        if self._head.item == before_item:
            self.prepend(new_item)

        else:
            new_node = ListNode(new_item)
            new_node._prev_node = travel._prev_node
            travel._prev_node = new_node

            travel.next = new_node
            if new_node.next is not None:
                new_node.next.previous = new_node

            self._size += 1

    def insert_after(self, after_item: Any, new_item: Any) -> None:
        """ Insert a new item after a specified item.

        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> self._linked_list.insert_after('dog', 'fish')
            >>> print(self._linked_list)
            ['cat', 'dog', 'fish', 'bird']

        Args:
            after_item (Any): the item that the user wishes to insert after.
            new_item (Any): the desired item to insert.

        Returns:
            None

        Raises:
            KeyError: if after_item is not found.
        
        """
        travel = self._head

        while travel is not None and travel.item != after_item:
            travel = travel.next

        if travel is None:
            raise IndexError(f'Did not find the node with value {after_item}.')

        if self._tail.item == after_item:
            self.append(new_item)

        else:
            new_node = ListNode(new_item, previous_node = travel, next_node = travel.next)

            travel.next = new_node
            if new_node.next is not None:
                new_node.next.previous = new_node

            self._size += 1

    @property
    def head(self) -> ListNode | None:
        """ Return the ListNode instance pointing at the _head of the linked list.
            Note: this method should be used for debug and test purposes only.
            
        Examples
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> _head = self._linked_list._head
            >>> print(_head.item)
            cat
        
        Returns:
            _head (ListNode | None): the ListNode instance representing the _head of the linked list.
            
        """
        return self._head

    @property
    def tail(self) -> ListNode | None:
        """ Return the ListNode instance pointing at the _tail of the linked list.
            Note: this method should be used for debug and test purposes only.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> _tail = self._linked_list._tail
            >>> print(_tail.item)
            bird
        
        Returns:
            _tail (ListNode | None): the ListNode instance representing the _tail of the linked list.
        """
        return self._tail

    @property
    def front(self) -> Any:
        """ Return the item at the front of the linked list.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> first_item = self._linked_list.front
            >>> print(first_item)
            cat
        
        Returns:
            front (Any): the item stored in the _head of the list
            
        Raises:
            IndexError: if the list is empty.
        
        """
        if self._size == 0:
            raise IndexError ('List is empty.')
        return self._head.item

    @property
    def back(self) -> Any:
        """ Return the item at the back of the linked list.

        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> last_item = self._linked_list.back
            >>> print(last_item)    
            bird

        Returns:
            last (Any): the item stored in the _tail of the list.
        
        Raises:
            IndexError: if the list is empty.
        """
        if self._size == 0:
            raise IndexError ('List is empty.')
        return self._tail.item

    def clear(self) -> None:
        """ Clear the linked list.

        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> self._linked_list.clear()
            >>> print(self._linked_list)
            []
        
        Returns:
            None
        """
        if self._size != 0:
            self._size = 0
            self._head = 0
            self._tail = 0

    def extract(self, item: Any) -> None:
        """ Extract an item from the Linked List.

        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> self._linked_list.extract('dog')
            >>> print(self._linked_list)
            ['cat', 'bird']

        Args:
            item (Any): the item to remove from the linked list.

        Returns:
            None

        Raises:
            KeyError: if the item is not found.
        """
        travel = self._head

        while travel is not None and travel.item != item:
            travel = travel._next_node

        if travel is None:  
            raise KeyError ('Item not found.')  

        if travel == self._head:
            self.pop_front()
        elif travel == self._tail:
            self.pop_back()
            
        travel._next_node._prev_node = travel._prev_node
        travel._prev_node._next_node = travel._next_node
        self._size -= 1

    @property
    def empty(self) -> bool:
        """ Property to determine whether the list is empty.
        
        Examples:
            >>> self._linked_list = LinkedList()
            >>> print(self._linked_list.empty)
            True
        
        Returns:
            bool: whether the list is empty.
        """
        if self._size == 0:
            return True
        return False

    def pop_front(self) -> None:
        """ Remove the first item in the linked list.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> self._linked_list.pop_front()
            >>> print(self._linked_list)
            ['dog', 'bird']
        
        Returns:
            None
        
        Raises:
            IndexError: if the list is empty.
            
        """
        if self._size == 0:
            raise IndexError ('List is empty.')
        self._head = self._head.next
        if self._head is not None:
            self._head.previous = None
        self._size -= 1
        

    def pop_back(self) -> None:
        """ Remove the last item in the linked list.

        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> self._linked_list.pop_back()
            >>> print(self._linked_list)
            ['cat', 'dog']

        Returns:
            None
        
        Raises:
            IndexError: if the list is empty.
        """
        if self._size == 0:
            raise IndexError ('List is empty.')
        self._tail = self._tail.previous
        self._tail.next = 0
        self._size -= 1
        

    def __contains__(self, item: Any) -> bool:
        """ Membership operator in.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print('dog' in self._linked_list)
            True
        
        Args:
            item (Any): the item to search for.
            
        Returns:
            bool: whether the linked list contains the item.
        """
        travel = self._head

        while travel != self._tail:
            if item == travel.item:
                return True
            travel = travel.next
            
        if item == self._tail.item:
            return True
        
        return False

    def __eq__(self, other: object) -> bool:
        """ Equality operator ==.
        
        Examples:
            >>> self._linked_list1 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> self._linked_list2 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(self._linked_list1 == self._linked_list2)
            True
        
        Args:
            other (object): the instance to compare self to.
            
        Returns:
            bool: whether the lists are equal (deep check).
        """
        if not isinstance(other, LinkedList):
            return False

        travel = self._head
        travel_other = other.head

        if len(other) == self._size:
            while travel != self._tail:
                if travel_other.item != travel.item:
                    return False
                travel_other = travel_other.next
                travel = travel.next
            if travel == self._tail:
                if travel_other.item != travel.item:
                    return False
            return True

    def __ne__(self, other: object) -> bool:
        """ Non-Equality operator !=.
        
        Examples:
            >>> self._linked_list1 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> self._linked_list2 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(self._linked_list1 != self._linked_list2)
            False
        
        Args:
            other (object): the instance to compare self to.
            
        Returns:
            bool: whether the lists are not equal (deep check).
        """
        return not self.__eq__(other)

    def __iter__(self) -> Any:
        """ Iterator operator.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> for item in self._linked_list:
            ...     print(item)
            cat
            dog
            bird
        
        Returns:
            Any: yields the item at ListNode.
        """
        travel = self._head

        while travel != self._tail:
            yield travel.item
            travel = travel.next
        if travel == self._tail:
            yield travel.item

    def __reversed__(self) -> Any:
        """ Reversed iterator operator.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> for item in reversed(self._linked_list):
            ...     print(item)
            bird
            dog
            cat
        
        Returns:
            Any: yields the item at ListNode.
        """
        travel = self._tail

        while travel != self._head:
            yield travel.item
            travel = travel.previous
        if travel == self._head:
            yield travel.item

    def __len__(self) -> int:
        """ len operator for getting length of the linked list.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> size = len(self._linked_list)
            >>> print(size)
            3
        
        Returns:
            int: the length of the LinkedList.
        """
        return self._size

    def __str__(self) -> str:
        """ Return a string representation of the data and structure.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(self._linked_list)
            ['cat', 'dog', 'bird']
            
        Returns:
            str: the string representation of the data and structure.
            
        """
        travel = self._head
        string = '['
        if self._head is None:
            return '[]'

        while travel != self._tail:
            string += str(travel) + ','
            travel = travel.next
        if travel == self._tail:
            string += str(travel)

        string += ']'

        return string
    
    def __repr__(self) -> str:
        """ Return a string representation of the data and structure.
        
        Examples:
            >>> self._linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(self._linked_list)
            ['cat', 'dog', 'bird']
            
        Returns:
            str: the string representation of the data and structure.
        
        """
        return self.__str__()
    
    def insert(self, other, position):
        if self.head is None or position == 0:
            other.next = self.head
            self._head = other  # Update self.head to point to the new node
        else:
            current = self.head
            count = 0
            while current.next is not None and count < position - 1:
                current = current.next
                count += 1
            other.next = current.next
            current.next = other
    
    def remove(self, node: ListNode):
        if node.previous is None:
            self.head = node.next
        else:
            node.previous.next = node.next

        if node.next is None:
            self.tail = node.prev
        else:
            node.next.prev = node.prev

        self.size -= 1

    # Midterm
    def to_array(self):
        from datastructures.array import Array
        array = []
        travel = self._linked_list.head
        while travel:
            array.append(travel.data)
            travel = travel.next
        return array


    # Midterm 2 Extra Credit
    def to_list(self) -> list:
        result_list = []
        current = self._head
        while current:
            result_list.append(current.item)
            current = current.next
        return result_list


    
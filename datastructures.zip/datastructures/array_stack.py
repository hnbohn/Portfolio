from typing import Any
from datastructures.array import Array

class ArrayStack:
    """ Class ArrayStack - representing a fixed-size stack using a 1D Array object.
        Stipulations:
        1. Must use an Array object as the internal data structure from the Array assignment.
        2. Must adhere to the docstring requirements per method, including raising
            raising appropriate exceptions where indicated.
    """

    def __init__(self, max_size: int = 0) -> None:
        """ Constructor

        Examples:
            >>> stack = ArrayStack(10)

        Args:
            max_size (int): the desired size of the stack.

        Returns:
            None
        """
        self.max_size = max_size
        self.array_stack = Array(max_size)
        self.index = -1

    def push(self, item: Any) -> None:
        """ Push an item onto the stack.
        
        Examples:
            >>> stack = ArrayStack(10)
            >>> stack.push('cat')
            
        Args:
            item (Any): the item to enqueue.
                
        Returns:
            None

        Raises:
            IndexError: if the stack is full.
        """
        if self.full:
            raise IndexError("Stack is full")
        self.index += 1
        self.array_stack[self.index] = item

    def pop(self) -> Any:
       """ Pop an item from the stack and return the item.
       
        Examples:
            >>> stack = ArrayStack(10)
            >>> stack.push('cat')
            >>> item = stack.pop()
            >>> print(item)
            cat

        Returns:
            Any: the item that is popped.

        Raises:
            IndexError: if the stack is empty.

        """
       if self.empty:
            raise IndexError("Stack is empty")
       item = self.array_stack[self.index]
       self.index -= 1
       return item
    
    def clear(self) -> None:
        """Clear the stack.
        
        Examples:
            >>> stack = ArrayStack(10)
            >>> stack.push('cat')
            >>> stack.clear()
            >>> print(stack.empty)
            True
                
        Returns:
            None
        """
        self.index = -1

    @property
    def top(self) -> Any:
        """Get the item at the top of the stack.
            
        Examples:
            >>> stack = ArrayStack(10)
            >>> stack.push('cat')
            >>> print(stack.top)
            cat
        
        Returns:
            Any: the item that is at the top of the stack.
            
        Raises:
                IndexError: if the stack is empty.
        """
        if self.empty:
            raise IndexError("Stack is empty")
        return self.array_stack[self.index]
    
    @property
    def max_size(self) -> int:
        """Get the maximum size of the stack.

        Examples:
            >>> stack = ArrayStack(10)
            >>> print(stack.max_size)
            10

        Returns:
            int: the max size of the stack.
        """
        return self._max_size
    
    @max_size.setter
    def max_size(self, value: int) -> None:
        if value < 0:
            raise ValueError("Max size must be non-negative")
        self._max_size = value

    @property
    def full(self) -> bool:
        """Check whether the stack is full.
        
        Examples:
            >>> stack = ArrayStack(10)
            >>> print(stack.full)
            False
            
        Returns:
            bool: True if the stack is full, False otherwise.
        """
        return self.index == self.max_size - 1

    @property
    def empty(self) -> bool:
        """Check whether the stack is empty.
        
        Examples:
            >>> stack = ArrayStack(10)
            >>> print(stack.empty)
            True
        """
        return self.index == -1

    def __eq__(self, other: object) -> bool:
        """Check if two stacks are equal.
        
        Examples:
            >>> stack1 = ArrayStack(10)
            >>> stack2 = ArrayStack(10)
            >>> print(stack1 == stack2)
            True
            
        Args:
            other (object): the object to compare to.
            
        Returns:
            bool: True if the stacks are equal, False otherwise.
        """
        if not isinstance(other, ArrayStack):
            return False
        return (
            self.max_size == other.max_size
            and self.array_stack == other.array_stack
            and self.index == other.index
        )
    
    def __ne__(self, other) -> bool:
        """Check if two stacks are not equal.
        
        Examples:
            >>> stack1 = ArrayStack(10)
            >>> stack2 = ArrayStack(10)
            >>> print(stack1 != stack2)
            False
            
        Args:
            other (object): the object to compare to.
            
        Returns:
            bool: True if the stacks are not equal, False otherwise.
        """
        return not self.__eq__(other)

    def __len__(self) -> int:
        """Get the number of items on the stack.
        
        Examples:
            >>> stack = ArrayStack(10)
            >>> print(len(stack))
            0
        
        Returns:
            int: the number of items on the stack.
        """
        return self.index + 1

    def __str__(self) -> str:
        """Get a string representation of the stack.
        
        Examples:
            >>> stack = ArrayStack(10)
            >>> print(stack)
            []
        
        Returns:
            str: the string representation of the stack.
        """
        return str([self.array_stack[i] for i in range(self.index + 1)])

    def __repr__(self) -> str:
        """Get a string representation of the stack.
        
        Examples:
            >>> stack = ArrayStack(10)
            >>> print(stack)
            []
        
        Returns:
            str: the string representation of the stack.
        """
        return self.__str__()
    

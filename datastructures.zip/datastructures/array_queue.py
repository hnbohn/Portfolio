from typing import Any
from .array import Array

class ArrayQueue:
    """ Class ArrayQueue - representing a circular array queue using a 1D Array
            Stipulations:
            1. Must use an Array object as the internal data structure.
            2. Storage must wrap-around the array.
            3. Must adhere to the docstring requirements per method, including raising
               raising appropriate exceptions where indicated.
    """

    def __init__(self, max_size: int = 0) -> None:
        """ Constructor

        Examples:
            >>> queue = ArrayQueue(10)

            Args:
                max_size (int): the desired size of the queue.

        Returns:
            None
        """
        self.max_size = max_size
        self.queue = Array(max_size)
        self.front_index = 0
        self.rear_index = -1
        self.size = 0

    def enqueue(self, item: Any) -> None:
        """ Enqueue an item onto the queue.

        Examples:
            >>> queue = ArrayQueue(10)
            >>> queue.enqueue('cat')

        Args:
            item (Any): the item to enqueue.

        Returns:
            None
        """
        if self.full:
            raise IndexError("Queue is full")
        self.rear_index = (self.rear_index + 1) % self.max_size
        self.queue[self.rear_index] = item
        self.size += 1

    def dequeue(self) -> Any:
        """ Dequeue an item from the queue and return the item.

        Examples:
            >>> queue = ArrayQueue(10)
            >>> queue.enqueue('cat')
            >>> item = queue.dequeue()
            >>> print(item)
            cat

        Returns:
            Any: the item that is dequeued.

        Raises:
            IndexError: if the queue is empty.
        """
        if self.empty:
            raise IndexError("Queue is empty")
        item = self.queue[self.front_index]
        self.queue[self.front_index] = None
        self.front_index = (self.front_index + 1) % self.max_size
        self.size -= 1
        return item

    def clear(self) -> None:
        """ Clear the queue.

        Examples:
            >>> queue = ArrayQueue(10)
            >>> queue.enqueue('cat')
            >>> queue.clear()

        Returns:
            None
        """
        self.queue = Array(self.max_size)
        self.front_index = 0
        self.rear_index = -1
        self.size = 0

    @property
    def front(self) -> Any:
        """ Get the item at the front of the queue.

        Examples:
            >>> queue = ArrayQueue(10)
            >>> queue.enqueue('cat')
            >>> print(queue.front)
            cat

        Returns:
            Any: the item that is at the front of the queue.

        Raises:
            IndexError: if the queue is empty.
        """
        if self.empty:
            raise IndexError("Queue is empty")
        return self.queue[self.front_index]

    @property
    def full(self) -> bool:
        """ Check whether the queue is full.

        Examples:
            >>> queue = ArrayQueue(3)
            >>> queue.enqueue('cat')
            >>> queue.enqueue('dog')
            >>> queue.enqueue('bird')
            >>> print(queue.full)
            True

        Returns:
            bool: True if the queue is full, False otherwise.
        """
        return self.size == self.max_size

    @property
    def empty(self) -> bool:
        """ Check whether the queue is empty.

        Examples:
            >>> queue = ArrayQueue(10)
            >>> print(queue.empty)
            True

        Returns:
            bool: True if the queue is empty, False otherwise.
        """
        return self.size == 0

    def __eq__(self, other: object) -> bool:
        """ Equality operator ==

        Examples:
            >>> queue1 = ArrayQueue(10)
            >>> queue2 = ArrayQueue(10)
            >>> print(queue1 == queue2)
            True

        Args:
            other (object): the instance to compare self to.

        Returns:
            bool: True if the queues are equal (deep check).
        """
        if not isinstance(other, ArrayQueue):
            return False

        if self.size != other.size:
            return False

        for i in range(self.size):
            if self.queue[(self.front_index + i) % self.max_size] != other.queue[
                (other.front_index + i) % other.max_size]:
                return False

        return True

    def __ne__(self, other: object) -> bool:
        """ Inequality operator !=

        Examples:
            >>> queue1 = ArrayQueue(10)
            >>> queue2 = ArrayQueue(10)
            >>> print(queue1 != queue2)
            False

        Args:
            other (object): the instance to compare self to.

        Returns:
            bool: True if the queues are not equal (deep check).
        """
        return not self.__eq__(other)

    def __len__(self) -> int:
        """ Get the number of items on the queue.

        Examples:
            >>> queue = ArrayQueue(10)
            >>> queue.enqueue('cat')
            >>> print(len(queue))
            1

        Returns:
            int: the number of items on the queue.
        """
        return self.size

    def __str__(self) -> str:
        """ Get the string representation of the queue.

        Examples:
            >>> queue = ArrayQueue(10)
            >>> queue.enqueue('cat')
            >>> print(queue)
            'cat'

        Returns:
            str: the string representation of the queue.
        """
        elements = []
        for i in range(self.size):
            elements.append(str(self.queue[(self.front_index + i) % self.max_size]))
        return '[' + ', '.join(elements) + ']'

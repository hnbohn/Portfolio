from __future__ import annotations
from typing import Any


from datastructures.list_node import ListNode



class LinkedList:
    """ Class LinkedList - representing an unordered linked list
        Depends on ListNode class to store the data, previous, and next nodes.
            Stipulations:
            1. Must manage the linked list using two ListNode objects (_head and _tail)
            2. Must adhere to the docstring requirements per method, including raising
               raising appropriate exceptions where indicated.
    """

    def __init__(self) -> None:
        """ Constructor for the LinkedList constructs an empty linked list.

        Examples:
            >>> linked_list = LinkedList()
            >>> print(linked_list)
            []
        
        Returns:
            None
        
        """
        self._head: ListNode | None = None
        self._tail: ListNode | None = None
        self._count: int = 0

    @staticmethod
    def from_list(py_list: list) -> LinkedList:
        """ Create a new LinkedList from a Python list.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list)
            ['cat', 'dog', 'bird']
        
        Args:
            py_list (list): list to convert to a linked list.

        Returns:
            A new LinkedList instance.
        
        Raises:
            TypeError: if py_list is not a list.
        """
        if not isinstance(py_list, list):
            raise TypeError(f'Expected a list, but was a {type(py_list)}')
        
        linked_list = LinkedList()
        for item in py_list:
            linked_list.append(item)
        return linked_list

    def append(self, item: Any) -> None:
        """ Append an item to the end of the list.

        Examples:
            >>> linked_list = LinkedList()
            >>> linked_list.append('cat')
            >>> linked_list.append('dog')
            >>> print(linked_list)
            ['cat', 'dog']
        
        Args:
            item: the desired data to append to the linked list.
        
        Returns:
            None
        """
        self._tail = ListNode(item, previous_node=self._tail)
        if self._head is None:
            self._head = self._tail
        else:
            if self._tail.previous is not None:
                self._tail.previous.next = self._tail

        self._count += 1

    def prepend(self, item: Any) -> None:
        """ Prepend an item to the beginning of the list.
        
        Examples:
            >>> linked_list = LinkedList()
            >>> linked_list.prepend('cat')
            >>> linked_list.prepend('dog')
            >>> print(linked_list)
            ['dog', 'cat']
        
        Args:
            item (Any): the desired data to prepend to the linked list.
            
        Returns:
            None
        
        """
        self._head = ListNode(item, next_node=self._head)
        if self._tail is None:
            self._tail = self._head
        else:
            if self._head.next is not None:
                self._head.next.previous = self._head

        self._count += 1

    def insert_before(self, before_item: Any, new_item: Any) -> None:
        """ Insert a new item before a specified item.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.insert_before('dog', 'fish')
            >>> print(linked_list)
            ['cat', 'fish', 'dog', 'bird']
                
        Args:
            before_item (Any): the item that the user wishes to insert before.
            new_item (Any): the desired item to insert.
        
        Returns:
            None
        
        Raises:
            KeyError: if before_item is not found.
        """
        travel: ListNode | None = self._head
        while travel is not None and travel.item != before_item:
            travel = travel.next

        if travel is None:
            raise KeyError(f'Item to insert before "{str(before_item)}" not found')
        
        if travel is self._head:
            self.prepend(new_item)
        
        else:
            node = ListNode(new_item, previous_node=travel.previous, next_node=travel)

            if travel.previous is not None:
                travel.previous.next = node
            else:
                self._head = node

            travel.previous = node
            self._count += 1

    def insert_after(self, after_item: Any, new_item: Any) -> None:
        """ Insert a new item after a specified item.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.insert_after('dog', 'fish')
            >>> print(linked_list)
            ['cat', 'dog', 'fish', 'bird']

        Args:
            after_item (Any): the item that the user wishes to insert after.
            new_item (Any): the desired item to insert.

        Returns:
            None

        Raises:
            KeyError: if after_item is not found.
        
        """
        travel: ListNode | None = self._head
        while travel is not None and travel.item != after_item:
            travel = travel.next

        if travel is None:
            raise KeyError(f'Item to insert after "{str(after_item)}" not found')

        if travel is self._tail:
            self.append(new_item)

        else:
            node = ListNode(new_item, travel, travel.next)

            if travel.next is not None:
                travel.next.previous = node
            else:
                self._tail = node

            travel.next = node
            self._count += 1

    @property
    def head(self) -> ListNode | None:
        """ Return the ListNode instance pointing at the head of the linked list.
            Note: this method should be used for debug and test purposes only.
            
        Examples
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> head = linked_list.head
            >>> print(head.item)
            cat
        
        Returns:
            head (ListNode | None): the ListNode instance representing the head of the linked list.
            
        """
        return self._head

    @property
    def tail(self) -> ListNode | None:
        """ Return the ListNode instance pointing at the tail of the linked list.
            Note: this method should be used for debug and test purposes only.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> tail = linked_list.tail
            >>> print(tail.item)
            bird
        
        Returns:
            tail (ListNode | None): the ListNode instance representing the tail of the linked list.
        """
        return self._tail

    @property
    def front(self) -> Any:
        """ Return the item at the front of the linked list.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> first_item = linked_list.front
            >>> print(first_item)
            cat
        
        Returns:
            front (Any): the item stored in the head of the list
            
        Raises:
            IndexError: if the list is empty.
        
        """
        if self._head is None:
            raise IndexError('List is empty.')

        return self._head.item

    @property
    def back(self) -> Any:
        """ Return the item at the back of the linked list.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> last_item = linked_list.back
            >>> print(last_item)    
            bird

        Returns:
            last (Any): the item stored in the tail of the list.
        
        Raises:
            IndexError: if the list is empty.
        """
        if self._tail is None:
            raise IndexError('List is empty.')

        return self._tail.item

    def clear(self) -> None:
        """ Clear the linked list.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.clear()
            >>> print(linked_list)
            []
        
        Returns:
            None
        """
        travel = self._head
        while travel is not None:
            temp = travel.next
            travel = None
            travel = temp

        self._head = self._tail = None
        self._count = 0

    def extract(self, item: Any) -> None:
        """ Extract an item from the Linked List.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.extract('dog')
            >>> print(linked_list)
            ['cat', 'bird']

        Args:
            item (Any): the item to remove from the linked list.

        Returns:
            None

        Raises:
            KeyError: if the item is not found.
        """
        travel: ListNode | None = self._head
        while travel is not None and travel.item != item:
            travel = travel.next

        if travel is None:
            raise KeyError(f'Item to extract "{str(item)}" not found')

        if travel.next is not None:
            travel.next.previous = travel.previous
        else:
            self._tail = travel.previous

        if travel.previous is not None:
            travel.previous.next = travel.next
        else:
            self._head = travel.next

        self._count -= 1

    @property
    def empty(self) -> bool:
        """ Property to determine whether the list is empty.
        
        Examples:
            >>> linked_list = LinkedList()
            >>> print(linked_list.empty)
            True
        
        Returns:
            bool: whether the list is empty.
        """
        return self._count == 0

    def pop_front(self) -> None:
        """ Remove the first item in the linked list.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.pop_front()
            >>> print(linked_list)
            ['dog', 'bird']
        
        Returns:
            None
        
        Raises:
            IndexError: if the list is empty.
            
        """
        if self.empty:
            raise IndexError('List is empty')

        if self._head is not None:
            self._head = self._head.next

            if self._head is not None:
                self._head.previous = None
            else:
                self._tail = None

        self._count -= 1

    def pop_back(self) -> None:
        """ Remove the last item in the linked list.

        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list.pop_back()
            >>> print(linked_list)
            ['cat', 'dog']

        Returns:
            None
        
        Raises:
            IndexError: if the list is empty.
        """
        if self.empty:
            raise IndexError('List is empty')

        if self._tail is not None:
            self._tail = self._tail.previous

            if self._tail is not None:
                self._tail.next = None
            else:
                self._head = None

        self._count -= 1

    def __contains__(self, item: Any) -> bool:
        """ Membership operator in.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print('dog' in linked_list)
            True
        
        Args:
            item (Any): the item to search for.
            
        Returns:
            bool: whether the linked list contains the item.
        """
        for iter in self:
            if iter == item:
                return True

        return False

    def __eq__(self, other: object) -> bool:
        """ Equality operator ==.
        
        Examples:
            >>> linked_list1 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list2 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list1 == linked_list2)
            True
        
        Args:
            other (object): the instance to compare self to.
            
        Returns:
            bool: whether the lists are equal (deep check).
        """
        if not isinstance(other, LinkedList):
            return False

        self_travel = self._head
        other_travel = other._head

        if len(self) != len(other):
            return False

        while self_travel is not None and other_travel is not None:
            if self_travel.item != other_travel.item:
                return False
            self_travel = self_travel.next
            other_travel = other_travel.next

        return True

    def __ne__(self, other: object) -> bool:
        """ Non-Equality operator !=.
        
        Examples:
            >>> linked_list1 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> linked_list2 = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list1 != linked_list2)
            False
        
        Args:
            other (object): the instance to compare self to.
            
        Returns:
            bool: whether the lists are not equal (deep check).
        """
        return not self.__eq__(other)

    def __iter__(self) -> Any:
        """ Iterator operator.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> for item in linked_list:
            ...     print(item)
            cat
            dog
            bird
        
        Returns:
            Any: yields the item at ListNode.
        """
        node: ListNode | None = self._head
        while node is not None:
            yield node.item
            node = node.next

    def __reversed__(self) -> Any:
        """ Reversed iterator operator.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> for item in reversed(linked_list):
            ...     print(item)
            bird
            dog
            cat
        
        Returns:
            Any: yields the item at ListNode.
        """
        node: ListNode | None = self._tail
        while node is not None:
            yield node.item
            node = node.previous

    def __len__(self) -> int:
        """ len operator for getting length of the linked list.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> size = len(linked_list)
            >>> print(size)
            3
        
        Returns:
            int: the length of the LinkedList.
        """
        return self._count

    def __str__(self) -> str:
        """ Return a string representation of the data and structure.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list)
            ['cat', 'dog', 'bird']
            
        Returns:
            str: the string representation of the data and structure.
            
        """
        if self._count == 0:
            return '[]'

        string: str = '['
        separator: str = ', '

        for item in self:
            string += str(item) + separator

        string = string[:len(string) - len(separator)]
        string += ']'

        return string
    
    def __repr__(self) -> str:
        """ Return a string representation of the data and structure.
        
        Examples:
            >>> linked_list = LinkedList.from_list(['cat', 'dog', 'bird'])
            >>> print(linked_list)
            ['cat', 'dog', 'bird']
            
        Returns:
            str: the string representation of the data and structure.
        
        """
        return self.__str__()
    

    def to_array(self):
        """Convert the contents of the LinkedList to an Array.
    
        Example:
            >>> print(my_linked_list)
            [5, 7, 17, 13, 11]
            >>> my_array = my_linked_list.to_array()
            >>> print(my_array)
            [5, 7, 17, 13, 11]
            
        Args:
            none
            
        Returns:
            Array: an array containing the items from the Linked List
        """
        from datastructures.array import Array

        array = Array(len(self))

        for i, item in enumerate(self):
            array[i] = item

        return array
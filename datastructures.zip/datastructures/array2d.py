# datastructures.array2d.Array2D

""" This module defines an Array2D class that represents a two-dimensional array. 
    The Array class uses a datastructures.Array object as the internal data structure. 
    The Array class adheres to the docstring requirements per method, including raising 
    appropriate exceptions where indicated.
"""



from typing import Any

from datastructures.array import Array


class Array2D:
    """ Class Array2D - representing 2D data using a 1D Array
            Stipulations:
            1. Must use an Array object as the internal data 
                structure from the Array assignment.
            2. Must adhere to the docstring requirements per method, 
                including raising raising appropriate exceptions where indicated.
    """

    def __init__(self, rows: int = 0, columns: int = 0, default_item_value = None) -> None:
        """ Array2D Constructor. Initializes the Array2D with the desired size and default value.
            
        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(array2d)
            [[None, None, None], [None, None, None]]

        Args:
            rows (int): the desired number of rows.
            columns (int): the desired number of columns.
            default_item_value (Any): the default value to initialize the Array2D items with.
        
        Returns:
            None
        
        Raises:
            ValueError: if the rows or columns are less than 0.
        """
        if rows < 0 or columns <0:
            raise ValueError ('Not large enough.')

        self._default_item_value = default_item_value
        self._columns = columns
        self._rows = rows
        self._items2d = Array(size = rows)

        for row in range(rows):
            self._items2d[row] = Array(size = columns, default_item_value = self._default_item_value)


    @staticmethod   
    def from_list(items: list) -> 'Array2D':
        """Create an Array2D from a 2D Python list. The function
            will take the dimensions of the list from the length of 
            of the list and the length of the first item in the list.
            The function will then create an Array2D with the same
        
        Examples:
            >>> items = [[1, 2, 3], [4, 5, 6]]
            >>> array2d = Array2D.from_list(items)
            >>> print(array2d)
            [[1, 2, 3], [4, 5, 6]]
        
        Args:
            items (list): a 2D list to create the Array2D from.
            
        Returns:    
            Array2D: the Array2D created from the 2D list.
        
        Raises:
            ValueError: if the 2D list is not rectangular or two-dimensional.
            ValueError: if list_items2d is not a list.
        """
        if not isinstance(items, list):
            raise ValueError

        for i in range(len(items)):
            if not isinstance(items[i], list):
                raise ValueError ('Not two-dimensional.')
            if i > 0 and len(items[i]) != len(items[i - 1]):
                raise ValueError ('Not rectangular.')

        new_array = Array2D(len(items), len(items[0]))

        for row in range(len(items)):
            for column in range(len(items[0])):
                new_array[row][column] = items[row][column]

        return new_array


    def __getitem__(self, row_index: int) -> Any:
        """ Bracket operator for accessing an item. This bracket operator is used to 
            access the first dimension (row). This should return an object that allows
            the bracket operator to be used again to access the second dimension (column).
        
        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> array2d[0][0] = 1
            >>> print(array2d[0][0])
            1
        
        Args:
            row_index (int): the index of the row to access.

        Returns:
            Any: the row object.

        Raises:
            IndexError: if the row_index is out of bounds.
        """
        if row_index < 0 or row_index > len(self._items2d):
            raise IndexError
        
        return self._items2d[row_index]


    @property
    def dimensions(self) -> tuple[int, int]:
        """ Property for getting dimensions of the Array2D.

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(array2d.dimensions)
            (2, 3)
            >>> rows, columns = array2d.dimensions
            >>> print(rows)
            2
            >>> print(columns)
            3
        
        Returns:
            tuple[int, int]: the dimensions of the Array2D.
        
        """
        return self._rows, self._columns


    def resize_columns(self, new_columns_len: int, default_item_value: Any = None) -> None:
        """ Resize the length of the columns. Must be able to handle both increasing and 
            decreasing the size of the columns. Must not lose any data when resizing
            the columns. If the new length is smaller, then the data will be truncated.
        
        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> array2d.resize_columns(4)
            >>> print(array2d.dimensions)
            (2, 4)
            >>> array2d.resize_columns(2)
            >>> print(array2d.dimensions)
            (2, 2)

        Args:
            new_columns_len (int): the new length of the columns.
            default_item_value (Any): the default value to initialize the new items with.
        
        Returns:
            None
        
        Raises:
            ValueError: if the new_columns_len is less than 0.

        """
        if new_columns_len <= 0:
            raise ValueError
        
        for i in range(self._rows):
            self._items2d[i].resize(new_columns_len, default_item_value)

        self._columns = new_columns_len


    def resize_rows(self, new_rows_len: int, default_item_value: Any = None) -> None:
        """ Resize the length of the rows. Must be able to handle both increasing and
            decreasing the size of the rows. Must not lose any data when resizing the rows.
            If the new length is smaller, then the data will be truncated.

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> array2d.resize_rows(4)
            >>> print(array2d.dimensions)
            (4, 3)
            >>> array2d.resize_rows(2)
            >>> print(array2d.dimensions)
            (2, 3)
        
        Args:
            new_rows_len (int): the new length of the rows.
            default_item_value (Any): the default value to initialize the new items with.

        Returns:
            None
        
        Raises:
            ValueError: if the new_rows_len is less than 0.
        """
        if new_rows_len <= 0:
            raise ValueError

        self._items2d.resize(new_rows_len, default_item_value)

        for i in range(self._rows, new_rows_len):
            self._items2d[i] = Array(self._columns, default_item_value)

        self._rows = new_rows_len


    def __eq__(self, other: object) -> bool:
        """ Equality operator ==.

        Examples:
            >>> array2d1 = Array2D(rows=2, columns=3)
            >>> array2d2 = Array2D(rows=2, columns=3)
            >>> print(array2d1 == array2d2)
            True
            >>> array2d2[0][0] = 1
            >>> print(array2d1 == array2d2)
            False
        
        Args:
            other (object): the object to compare to.
        
        Returns:
            bool: True if the objects are equal, False otherwise.
        """
        if not isinstance(other, Array2D):
            return False

        rows, columns = other.dimensions

        if rows == self._rows and columns == self._columns:
            for i in range(self._rows):
                for j in range(self._columns):
                    if other[i][j] != self[i][j]:
                        return False
            
        return True


    def __ne__(self, other: object) -> bool:
        """ Non-equality operator !=.
        
        Examples:
            >>> array2d1 = Array2D(rows=2, columns=3)
            >>> array2d2 = Array2D(rows=2, columns=3)
            >>> print(array2d1 != array2d2)
            False
            >>> array2d2[0][0] = 1
            >>> print(array2d1 != array2d2)
            True
        
        Args:
            other (object): the object to compare to.
        
        Returns:
            bool: True if the objects are not equal, False otherwise.
        """
        return not self.__eq__(other)


    def __contains__(self, item: Any) -> bool:
        """ Contains operator (in).

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(3 in array2d)
            False
            >>> array2d[0][0] = 3
            >>> print(3 in array2d)
            True
        
        Args:
            item (Any): the item to check for.

        Returns:    
            bool: True if the item is in the Array2D, False otherwise.
        """
        for i in range(self._rows):
            if item in self._items2d[i]:
                return True
        
        return False
    

    def clear(self) -> None:
        """ Clear operator. Clears the Array2D.

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> array2d.clear()
            >>> print(array2d)
            [[None, None, None], [None, None, None]]
        
        Returns:
            None
        """
        self._items2d = Array(size = 0)

        for row in range(0):
            self._items2d[row] = Array(size = columns, default_item_value = self._default_item_value)

        self._rows = 0
        self._columns = 0


    def __str__(self) -> str:
        """ Return a string representation of the data and structure

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(array2d)
            [[None, None, None], [None, None, None]]
        
        Returns:
            str: the string representation of the data and structure.
        
        """
        string = "["

        for i in range(self._rows):
            string += "["
            for j in range(self._columns):
                string += str(self._items2d[i][j])
                if j < self._columns -1:
                    string += ","
            string += "]"
            if i < self._rows - 1:
                string += ","

        string += "]"

        return string


    def __repr__(self) -> str:
        """ Return a string representation of the data and structure.

        Examples:
            >>> array2d = Array2D(rows=2, columns=3)
            >>> print(repr(array2d))
            [[None, None, None], [None, None, None]]
        
        Returns:
            str: the string representation of the data and structure.
        """
        return self.__str__()


    def __setitem__(self, index, data):

        self._items2d[index] = data


    # Midterm 2 Extra Credit
    def to_list(self) -> list:
        return [[item for item in row] for row in self._items2d]
